import React from 'react'

function Excercise() {
  return (
    <div>
        <h5 className='card p-5 fw-bold border-top border-primary headings'><u>Daily Routine Excercies For Good Health</u></h5>
        <div className='container d-flex flex-wrap'>
         <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Flat Belly</h4>
            <img src="https://i.pinimg.com/originals/d8/73/3f/d8733f27b7e8510f399f6d4e8fb0f87c.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Back Strenghten</h4>
            <img src="https://images.squarespace-cdn.com/content/v1/583a5b7315d5db6612fa14d6/1589154144667-EICXJVKFI8AGM2NREG7K/birdog-abdominal.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Build Back Strong Shoulder</h4>
            <img src="https://i.pinimg.com/originals/d8/4c/e3/d84ce3448cc82ea9abe9ea7421bfc029.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Strong Legs</h4>
            <img src="https://miro.medium.com/v2/resize:fit:1358/1*8rotl-jfuExo-EYBmOzmsw.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>core ABS</h4>
            <img src="https://i.pinimg.com/originals/42/38/50/423850992bdf5a6d34cad66aa2040767.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Shoulder Pain Relief</h4>
            <img src="https://i.pinimg.com/originals/72/a7/c0/72a7c0a29b85d7a16d987f29c7802030.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>scatica Pain Relief</h4>
            <img src="https://images.squarespace-cdn.com/content/v1/583a5b7315d5db6612fa14d6/1589154310990-818039W06M9T0AA0A5Q0/classic-bridge.gif" alt="" />
            </div>
            <div className="card border m-3" style={{width:"250px"}}>
            <h4 className='m-2 mx-3'>Push Ups</h4>
            <img src="https://media.self.com/photos/57d88776d3276fe2329462f6/master/w_1600%2Cc_limit/DIAMOND_PUSHUP.gif" alt="" />
            </div>
        </div>
    </div>
  )
}

export default Excercise
